package katana.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;


import katana.network.EnrichWithKatanaModVariables;

import katana.init.EnrichWithKatanaModItems;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Base_style_tooltip_prProcedure {
	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
    execute(event.getEntity(), event.getItemStack());
}

	public static void execute(Entity entity, ItemStack itemstack) {
		execute(null, entity, itemstack);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (!(EnrichWithKatanaModItems.STEEL_KATANA.get() == itemstack.getItem()) && !(EnrichWithKatanaModItems.REINFORCED_KATANA.get() == itemstack.getItem()) && !(EnrichWithKatanaModItems.DIVINE_KATANA.get() == itemstack.getItem())) {
			{
				double _setval = 1;
				entity.getCapability(EnrichWithKatanaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.tooltip_cheak = _setval;
					capability.syncPlayerVariables(entity);
				});
			((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE).setBaseValue(1);
			((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_SPEED).setBaseValue(4);


			}
		}
	}
}
